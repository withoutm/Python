# text = "ма я мама спать сегодня ма"
# n=int(text.__len__()/2)
# sub_text1= text[:n]
# if sub_text1.__contains__("ма"):
#     print(sub_text1.count("ма"))
# sub_text2= text[:n:len:1]
# print(sub_text2)
# print(sub_text1)
# lenght=len(text)
# print(lenght)
